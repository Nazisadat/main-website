import React from 'react'

export default function Inside() {
    return (
        <div>
            inside
        </div>
    )
}
