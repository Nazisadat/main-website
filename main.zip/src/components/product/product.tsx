import React, { useState } from "react";
import { Col, Container, Row } from "react-bootstrap";
import "./product.scss";
import { AiOutlineArrowDown } from "react-icons/ai";

export default function Product() {
  const [showul1, setshowul1] = useState<boolean>(false);
  const [showul2, setshowul2] = useState<boolean>(false);

  function toggleul1() {
    setshowul1(!showul1);
  }

  function toggleul2() {
    setshowul2(!showul2);
  }

  return (
    <div className="product">
      <Container className="product">
        <Row>
          <Col className="d-sm-none d-md-block" md={4}>
            <div className="filter">
              <ul>
                <li>Price Sort</li>
                <li>
                  Platform{" "}
                  <span
                    onClick={toggleul1}
                    className={`${showul1 ? "active-arrow" : ""}`}
                  >
                    <AiOutlineArrowDown />
                  </span>
                  <ul className={`${showul1 ? "has-expand" : " active-ul"}`}>
                    <li>
                      <input type="checkbox" /> Windows
                    </li>
                    <li>
                      <input type="checkbox" /> Mac
                    </li>
                  </ul>
                </li>
                <li>
                  Form Factor{" "}
                  <span
                    onClick={toggleul2}
                    className={`${showul2 ? "active-arrow" : ""}`}
                  >
                    <AiOutlineArrowDown />
                  </span>
                  <ul className={`${showul2 ? "has-expand" : " active-ul"}`}>
                    <li>
                      <input type="checkbox" /> 1U
                    </li>
                    <li>
                      <input type="checkbox" /> 2U
                    </li>
                    <li>
                      <input type="checkbox" /> 3U
                    </li>
                    <li>
                      <input type="checkbox" /> 5U
                    </li>
                  </ul>
                </li>
                <li>CPU Sockets</li>
                <li>Form Fatcor</li>
                <li>
                  Max Ram
                  <div className="slidecontainer">
                    <input
                      type="range"
                      min="1"
                      max="100"
                      defaultValue="50"
                      className="slider"
                      id="myRange"
                    />
                    <p>
                      Value: <span id="demo"></span>
                    </p>
                  </div>
                </li>
              </ul>
              <button>APPLY</button>
            </div>
          </Col>
          <Col sm={12} md={8}>
            44444
          </Col>
        </Row>
      </Container>
    </div>
  );
}
